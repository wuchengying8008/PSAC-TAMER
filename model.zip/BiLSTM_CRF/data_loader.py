import numpy as np
from sklearn.model_selection import train_test_split

tag2id = {"emotion": 0, "interest": 1, "background-contexts": 2,"topic-shifts":3}
id2tag = {v: k for k, v in tag2id.items()}
#tlp = "../data/{}"
tlp="/home/src/model/data/{}"


def load_text(name, word2id=None):
    lines = []
    if not word2id:
        word2id, flag = {"emotion": 0, "interest": 1, "background-contexts": 2,"topic-shifts":3}, True
    else:
        flag = False

    with open(tlp.format(name), encoding="utf-8") as fp:
        buff = []
        for line in fp:
            print(line.strip())
            if  line.strip():
                lines.append(line)
                buff = []
            else:
                buff.append(line.strip())
    x_train, y_train, maxlen = [], [], 60
    for line in lines:
        x, y = [], []
        v = line.split()
        for w in v:
            #w = v.split("\t")
            #w=v
            if w not in word2id:
               continue
               # word2id[w] = len(word2id)
           # print(word2id.get(w, 1))
            x.append(word2id.get(w, 1))
            y.append(tag2id[w])
        if len(x) < maxlen:
            x = x + [0] * (maxlen - len(x))
            y = y + [0] * (maxlen - len(y))
        x = x[:maxlen]
        y = y[:maxlen]
        x_train.append(x)
        y_train.append(y)
    return np.array(x_train), np.array(y_train), word2id

    # return np.array(x_train[:10000]), np.array(y_train[:10000]), word2id


def load_data():
    x_tags=load_text("/home/tags/tag.json")
    x_train, y_train, word2id = load_text("train.txt")
    x_train, x_valid, y_train, y_valid = train_test_split(x_train, y_train, test_size=0.1)
    print("train:", x_train.shape, y_train.shape)
    print("valid:", x_valid.shape, y_valid.shape)
    x_test, y_test, _ = load_text("test.txt", word2id)

    print("test len:", len(x_test))
    print(id2tag)
    return word2id, tag2id, x_train, x_test, x_valid, y_train, y_test, y_valid, id2tag


#def main():
    #    word = load_data()
#    print(len(word))


#if __name__ == '__main__':
#    main()