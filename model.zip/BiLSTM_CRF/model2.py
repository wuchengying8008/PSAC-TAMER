import torch
import torch.nn as nn
import torch.optim as optim
from TorchCRF import CRF
from torch.utils.data import DataLoader, Dataset, random_split


class NERDataset(Dataset):
    def __init__(self, data, tags):
        self.data = data
        self.tags = tags

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.tags[idx]


class BiLSTM_CRF(nn.Module):
    def __init__(self, vocab_size, tag_to_ix, embedding_dim, hidden_dim):
        super(BiLSTM_CRF, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim // 2,
                            num_layers=1, bidirectional=True)
        self.hidden2tag = nn.Linear(hidden_dim, len(tag_to_ix))
        self.crf = CRF(len(tag_to_ix))

    def forward(self, sentences):
        embedded = self.embedding(sentences)
        lstm_out, _ = self.lstm(embedded)
        emissions = self.hidden2tag(lstm_out)
        return emissions

    def loss(self, sentences, tags):
        emissions = self.forward(sentences)
        return -self.crf(emissions, tags)

    def decode(self, sentences):
        emissions = self.forward(sentences)
        return self.crf.decode(emissions)


vocab = ["emotion", "interest", "topic-shifts", "background-contexts", "happy",
         "Urgency", "Surprise","Worry","Doubt","Confident","Curiosity","Disappointment",
         "Relief","Fearful","Optimistic","Relief","Worry","Frustration","Cautious",
         "Determined","Anxiety","Fearful","Urgent","Excitement","Calm","Empathy"]
tag_to_ix = {"emotion": 0, "interest": 1, "background-contexts": 2,"topic-shifts":3}
data = [torch.tensor([vocab.index(w) for w in ["emotion", "interest", "topic-shifts", "background-contexts"]])]
tags = [torch.tensor([tag_to_ix["emotion"], tag_to_ix["emotion"], tag_to_ix["emotion"]])]
dataset = NERDataset(data, tags)
train_dataset, val_dataset = random_split(dataset, [len(dataset) - 5, 5])
train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False)

model = BiLSTM_CRF(len(vocab), tag_to_ix, embedding_dim=50, hidden_dim=100)
optimizer = optim.Adam(model.parameters(), lr=0.01)
criterion = model.loss

for epoch in range(110):
    model.train()
    total_loss = 0
    for sentences, tags in train_loader:
        optimizer.zero_grad()