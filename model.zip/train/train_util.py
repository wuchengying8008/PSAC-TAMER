# from read_file_pkl import load_data
import torch.optim as op
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from src.common.config import config

from src.model.BiLSTM_CRF.data_loader import load_data
from src.model.BiLSTM_CRF.model import NERDataset, NERLSTM_CRF

word2id, tag2id, x_train, x_test, x_valid, y_train, y_test, y_valid, id2tag = load_data()

def parse_tags(text, path):
    tags = [id2tag[idx] for idx in path]
    begin = 0
    end = 0
    res = []
    for idx, tag in enumerate(tags):
        if tag.startswith("B"):
            begin = idx
        elif tag.startswith("E"):
            end = idx
            word = text[begin:end + 1]
            label = tag[2:]
            res.append((word, label))
        elif tag == 'O':
            res.append((text[idx], tag))
    return res

def utils_to_train():
    Config = config()
    device = torch.device('cpu')
    max_epoch = Config.max_epoch
    batch_size = Config.batch_size
    num_workers = Config.num_workers
    Config.vocab_size = len(word2id)
    Config.num_tags = len(tag2id)

    train_dataset = NERDataset(x_train, y_train)
    valid_dataset = NERDataset(x_valid, y_valid)
    test_dataset = NERDataset(x_test, y_test)

    train_data_loader = DataLoader(train_dataset, batch_size=Config.batch_size, shuffle=True, num_workers=num_workers)
    valid_data_loader = DataLoader(valid_dataset, batch_size=Config.batch_size, shuffle=True, num_workers=num_workers)
    test_data_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=True, num_workers=num_workers)

    model = NERLSTM_CRF(Config).to(device)
    criterion = nn.CrossEntropyLoss(ignore_index=0)
    optimizer = op.Adam(model.parameters(), lr=Config.lr, weight_decay=Config.weight_decay)

    return max_epoch, device, train_data_loader, valid_data_loader, test_data_loader, optimizer, model
