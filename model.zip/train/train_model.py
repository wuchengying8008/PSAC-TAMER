import torch
from sklearn.metrics import precision_score, recall_score, f1_score, classification_report

from src.model.BiLSTM_CRF.data_loader import load_data
from src.model.train.train_util import utils_to_train, parse_tags

word2id = load_data()[0]
max_epoch, device, train_data_loader, valid_data_loader, test_data_loader, optimizer, model =utils_to_train()

class ModelBuild(object):
    def train(self):
        for epoch in range(max_epoch):

            # model train
            model.train()

            for index, batch in enumerate(train_data_loader):
                optimizer.zero_grad()
                # train data -->gpu
                x = batch['x'].to(device)
                mask = (x > 0).to(device)
                y = batch['y'].to(device)
                loss = model.log_likelihood(x, y, mask)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(parameters=model.parameters(),
                                               max_norm=10)

                optimizer.step()
                if index % 2 == 0:
                    print('epoch:%5d,------------loss:%f' %
                          (epoch, loss.item()))
            aver_loss = 0
            preds, labels = [], []
            for index, batch in enumerate(valid_data_loader):
                model.eval()
                val_x, val_y = batch['x'].to(device), batch['y'].to(device)
                val_mask = (val_x > 0).to(device)
                predict = model(val_x, val_mask)
                loss = model.log_likelihood(val_x, val_y, val_mask)
                aver_loss += loss.item()
                leng = []
                res = val_y.cpu()
                for i in val_y.cpu():
                    tmp = []
                    for j in i:
                        if j.item() > 0:
                            tmp.append(j.item())
                    leng.append(tmp)

                for index, i in enumerate(predict):
                    preds += i[:len(leng[index])]

                for index, i in enumerate(val_y.tolist()):
                    labels += i[:len(leng[index])]

            aver_loss /= (len(valid_data_loader) * 64)
            precision = precision_score(labels, preds, average='macro')
            recall = recall_score(labels, preds, average='macro')
            f1 = f1_score(labels, preds, average='macro')
            print("labels:",labels)
            print("preds:", preds)
            report = classification_report(labels, preds)
            print(report)
            torch.save(model.state_dict(), 'result/model.BiLSTM_CRF')

    def predict(self, input_str=""):
        model.load_state_dict(torch.load("result/model.biLSTM_CRF"))
        model.eval()
        if not input_str:
            input_str = input("Input texts: ")
        input_vec = []
        for char in input_str:
            if char  in word2id:
                continue
                #input_vec.append(word2id['[unknown]'])
            else:
                input_vec.append(word2id[char])

        # convert to tensor
        sentences = torch.tensor(input_vec).view(1, -1).to(device)
        mask = sentences > 0
        paths = model(sentences, mask)

        res = parse_tags(input_str, paths[0])
        return [],[]


    def test(self, test_dataloader):
        model.load_state_dict(torch.load("result/model.biLSTM_CRF"))

        aver_loss = 0
        preds, labels = [], []
        for index, batch in enumerate(test_dataloader):
            model.eval()
            val_x, val_y = batch['x'].to(device), batch['y'].to(device)
            val_mask = (val_x > 0).to(device)
            predict = model(val_x, val_mask)
            # loss forword
            loss = model.log_likelihood(val_x, val_y, val_mask)
            aver_loss += loss.item()
            # the length of lags
            leng = []
            for i in val_y.cpu():
                tmp = []
                for j in i:
                    if j.item() > 0:
                        tmp.append(j.item())
                leng.append(tmp)

            for index, i in enumerate(predict):
                preds += i[:len(leng[index])]

            for index, i in enumerate(val_y.tolist()):
                labels += i[:len(leng[index])]

        # los and metric
        aver_loss /= len(test_dataloader)
        precision = precision_score(labels, preds, average='macro')
        recall = recall_score(labels, preds, average='macro')
        f1 = f1_score(labels, preds, average='macro')
        report = classification_report(labels, preds)
        print(report)


if __name__ == '__main__':
    cn = ModelBuild()
    cn.train()
    cn.predict("how are you ")