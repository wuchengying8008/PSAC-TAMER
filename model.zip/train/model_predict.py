
import torch
from sklearn.metrics import precision_score, recall_score, f1_score, classification_report
from src.model.train.train_util import utils_to_train, parse_tags
from src.model.BiLSTM_CRF.data_loader import load_data
from src.model.train.train_util import utils_to_train, parse_tags


def model_predict( input_str=""):
     state_dict=torch.load("result/model.biLSTM_CRF")
     model.load_state_dict(state_dict)
     model.eval()
     if not input_str:
        input_str = input("Input texts: ")
     input_vec = []
     for char in input_str:
        if char in word2id:
            continue
            # input_vec.append(word2id['[unknown]'])
        else:
            input_vec.append(word2id[char])

     # convert to tensor
     sentences = torch.tensor(input_vec).view(1, -1).to(device)
     mask = sentences > 0
     paths = model(sentences, mask)

     res = parse_tags(input_str, paths[0])
     return res

if __name__ == '__main__':
     word2id = load_data()[0]
     max_epoch, device, train_data_loader, valid_data_loader, test_data_loader, optimizer, model = utils_to_train()
     print(model_predict("I can see why this might be a nerve-wracking time for investors."))